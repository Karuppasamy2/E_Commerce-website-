package com.project.e_commerce.repo;

import com.project.e_commerce.model.Product;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface ProductRepository extends CrudRepository<Product,Integer>{

    @Query("SELECT p FROM Product p WHERE " +
            "LOWER(p.name) LIKE LOWER(CONCAT('%',:keyword,'%')) OR " +
            "LOWER(p.description) LIKE LOWER(CONCAT('%',:keyword,'%')) OR " +
            "LOWER(p.brand) LIKE LOWER(CONCAT('%',:keyword,'%')) OR "  +
            "LOWER(p.category) LIKE LOWER(CONCAT('%',:keyword,'%')) ")


    List<Product> findByProduct(@Param("keyword") String Keyword);


}
